setwd("C:\\Users\\it24102758\\Desktop\\IT24102758")
#1
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
#2
str(branch_data)
summary(branch_data)
#3
boxplot(branch_data$Sales_X1,main="Boxplot of Sales",horizontal=TRUE)
#4
summary(branch_data$Advertising_X2)
IQR_Advertising<-IQR(branch_data$Advertising_X2)
print(IQR_Advertising)
#5
get.outliers<-function(X){
  q1<-quantile(X,0.25)
  q3<-quantile(X,0.75)
  iqr<-q3-q1
  lower_bound<-q1-1.5*iqr
  upper_bound<-q3+1.5*iqr
  outliers<-X[X<lower_bound|X>upper_bound]
  return(outliers)
}
get.outliers(branch_data$Years_X3)

