
setwd("C:\\Users\\ADMIN\\Desktop\\it24102758")
snack <- c("A", "B", "C", "D")          
observed <- c(120, 95, 85, 100)         

# -----------------------------
# Part (i): State Hypotheses
# -----------------------------
# Null Hypothesis (H0): All snack types are equally preferred (P = 0.25 each)
# Alternative Hypothesis (H1): Snack types are NOT equally preferred

# -----------------------------
# Part (ii): Perform Chi-Square Goodness of Fit Test
# -----------------------------
# Use equal probabilities for each snack type
result <- chisq.test(observed, p = rep(1/4, 4))

# Display test results
print(result)

# -----------------------------
# Part (iii): Interpretation / Conclusion
# -----------------------------
alpha <- 0.05  # Significance level

if (result$p.value < alpha) {
  cat("Conclusion: Reject the null hypothesis.\n")
  cat("Snack preferences are NOT equally likely.\n")
} else {
  cat("Conclusion: Fail to reject the null hypothesis.\n")
  cat("Snack preferences are equally likely.\n")
}

